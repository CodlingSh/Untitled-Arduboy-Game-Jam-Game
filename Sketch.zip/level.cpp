#include "levels.h"
#include <avr/pgmspace.h>

const uint8_t level1[] = {
  {},
}
