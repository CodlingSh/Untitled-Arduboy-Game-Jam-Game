#ifndef PLAYER_H
#define PLAYER_H

#include <Arduboy2.h>
#include <ArduboyTones.h>

// 8x16, 1 frame(s)
// Image: 18 bytes, Mask: 16 bytes
// Example: Sprites::drawExternalMask(x, y, human, humanMask, frame, 0);
const uint8_t PROGMEM human[] = {
  8, 16,
  0x80, 0xde, 0xfb, 0xef, 0xef, 0xfb, 0xde, 0x80, 0x01, 0x00, 0x07, 0x03,
  0x03, 0x07, 0x00, 0x01,
};

const uint8_t PROGMEM humanMask[] = {
  0x80, 0xde, 0xff, 0xff, 0xff, 0xff, 0xde, 0x80, 0x01, 0x00, 0x07, 0x03,
  0x03, 0x07, 0x00, 0x01,
};

class Player {
  private:
    Arduboy2 *ab;
    ArduboyTones *sound;
    // ArduboyTones *sound;
    uint16_t x = 60;
    uint16_t y = 26;
    uint16_t map_width = 127;
    uint16_t map_height = 127;

    uint8_t *currSprite = human;

  public:
    Player(Arduboy2 *abPtr, ArduboyTones *soundPtr)
      : ab(abPtr), sound(soundPtr) {}
    
    uint8_t get_center_x() {
      return x + 4;
    }

    uint8_t get_center_y() {
      return y + 6;
    }

    void set_map_data(uint8_t map_data) {
      if (map_data & (1 << 7)) {
        map_width = 256;
      } else {
        map_width = 128;
      }

      if (map_data & (1 << 6)) {
        map_height = 128;
      } else {
        map_height = 64;
      }
    }

    void update() {
      if (ab->pressed(LEFT_BUTTON)) {
        x--;
      } else if (ab->pressed(RIGHT_BUTTON)) {
        x++;
      }

      if (ab->pressed(UP_BUTTON)) {
        y--;
      } else if (ab->pressed(DOWN_BUTTON)) {
        y++;
      }

      // Set boundaries for player
      if (x <= 0) { 
        x = 1;
      } else if (x >= map_width - 8) {
        x = map_width - 8 - 1;
      }

      if (y <= 0) {
        y = 1;
      } else if (y >= map_height - 11) {
        y = map_height - 11 - 1;
      }
    }

    void draw(uint16_t offset_x, uint16_t offset_y) {
      Sprites::drawExternalMask(x - offset_x, y - offset_y, human, humanMask, 0, 0);
      ab->print("X: ");
      ab->println(x);
      ab->print("Y: ");
      ab->println(y);
    }
};

#endif