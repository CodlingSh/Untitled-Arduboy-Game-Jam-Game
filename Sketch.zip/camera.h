#ifndef CAMERA_H
#define CAMERA_H

class Camera {
  private:
    int16_t map_scroll_x = 0;
    int16_t map_scroll_y = 0;
    uint16_t map_width = 127;
    uint16_t map_height = 127;

  public:
    Camera(uint16_t scroll_x, uint16_t scroll_y)
      : map_scroll_x(scroll_x), map_scroll_y(scroll_y) {}

    //Getters
    uint16_t scroll_x() {
      return map_scroll_x;
    }

    uint16_t scroll_y() {
      return map_scroll_y;
    }

    void set_map_data(uint8_t map_data) {
      if (map_data & (1 << 7)) {
        map_width = 256;
      } else {
        map_width = 128;
      }

      if (map_data & (1 << 6)) {
        map_height = 128;
      } else {
        map_height = 64;
      }
    }

    void update(uint16_t target_x, uint16_t target_y) {
      map_scroll_x = target_x - 64;
      map_scroll_y = target_y - 32;



      // Clamp horizontally
      if (map_scroll_x < 0) map_scroll_x = 0;
      if (map_scroll_x > map_width - 128) map_scroll_x = map_width - 128;
    
      // Clamp vertically
      if (map_scroll_y < 0) map_scroll_y = 0;
      if (map_scroll_y > map_height - 64) map_scroll_y = map_height - 64;
    }
};

#endif