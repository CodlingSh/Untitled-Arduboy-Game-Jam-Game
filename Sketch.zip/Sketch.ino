#include "player.h"
#include "level.h"
#include <Arduboy2.h>
#include <ArduboyTones.h>
#include "enemy.h"
#include "camera.h"

Arduboy2 ab;
ArduboyTones sound(ab.audio.enabled);
Camera c(0, 0);
Player player(&ab, &sound);
Enemy enemy1(90, 20);
Enemy enemy2(113, 50);
Enemy enemy3(20, 100);
Enemy enemy4(60, 75);
Level level(&ab, 0b01111111);

void setup() {
  ab.begin();
  ab.setFrameRate(60);
}

void loop() {
  if (!ab.nextFrame()) return;

  ab.pollButtons();
  ab.clear();

  update();
  draw();

  ab.display();
}

void update() {
  player.update();
  player.set_map_data(level.get_map_data());
  c.set_map_data(level.get_map_data());
  c.update(player.get_center_x(), player.get_center_y());
}

void draw() {
  player.draw(c.scroll_x(), c.scroll_y());
  level.draw(c.scroll_x(), c.scroll_y());
  enemy1.draw(c.scroll_x(), c.scroll_y());
  enemy2.draw(c.scroll_x(), c.scroll_y());
  enemy3.draw(c.scroll_x(), c.scroll_y());
  enemy4.draw(c.scroll_x(), c.scroll_y());
}
